'use strict'

module.exports = function () {
  return Array.from(arguments)
    .slice(0, arguments.length - 1)
    .join('')
}
